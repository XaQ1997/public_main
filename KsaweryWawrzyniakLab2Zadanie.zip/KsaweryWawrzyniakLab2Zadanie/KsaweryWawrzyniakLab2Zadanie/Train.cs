﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Train
    {
        private int number, numberTrucks;
        private readonly List<Truck> truckList = new List<Truck>();

        /// <summary>
        /// Metoda zwracająca numer pociągu
        /// </summary>
        /// <returns></returns>
        public int GetNumber()
        {
            return number;
        }

        /// <summary>
        /// Metoda dodająca wagon
        /// </summary>
        /// <param name="truck"></param>
        public void AddTruck(Truck truck)
        {
            truckList.Add(truck);
        }
    }
}
