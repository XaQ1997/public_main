﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Station
    {
        protected int numberPassagers;
        protected string name;
        protected List<Passager> passagerList = new List<Passager>();

        public Station(string named)
        {
            name = named;
        }

        /// <summary>
        /// Metoda zwracająca ilość pasażerów
        /// </summary>
        /// <returns></returns>
        public int GetNumberPassagers()
        {
            return numberPassagers;
        }

        /// <summary>
        /// Metoda zwracająca nazwę
        /// </summary>
        /// <returns></returns>
        public string GetName()
        {
            return name;
        }


        /// <summary>
        /// Metoda zwracająca pasażera
        /// </summary>
        /// <param name="iter"></param>
        /// <returns></returns>
        public Passager GetPassager(int iter)
        {
            return passagerList[iter];
        }

        /// <summary>
        /// Pasażer wsiada do pociągu
        /// </summary>
        /// <param name="passager"></param>
        public void PassagerIn(Passager passager)
        {
            numberPassagers--;
            passagerList.Remove(passager);
        }

        /// <summary>
        /// Pasażer czeka
        /// </summary>
        /// <param name="passager"></param>
        public virtual void PassagerWait(Passager passager)
        {
            numberPassagers++;
            passager.SetBegin(name);
            passagerList.Add(passager);
        }
    }
}
