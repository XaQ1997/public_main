﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KsaweryWawrzyniakLab2Zadanie
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Metoda tworząca nową linię
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLine_Click(object sender, EventArgs e)
        {
            int nr = Int32.Parse(textBoxNumberLine.Text);
            Line line = new Line(nr);
        }

        private void buttonStation_Click(object sender, EventArgs e)
        {
            string name = textBoxStation.Text;
            Station station = new Station(name);
    }
}
