﻿namespace KsaweryWawrzyniakLab2Zadanie
{
    partial class FormMain
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxLines = new System.Windows.Forms.GroupBox();
            this.textBoxNumberLine = new System.Windows.Forms.TextBox();
            this.buttonLine = new System.Windows.Forms.Button();
            this.labelNumberLine = new System.Windows.Forms.Label();
            this.groupBoxStation = new System.Windows.Forms.GroupBox();
            this.textBoxStation = new System.Windows.Forms.TextBox();
            this.labelName = new System.Windows.Forms.Label();
            this.buttonStation = new System.Windows.Forms.Button();
            this.groupBoxLines.SuspendLayout();
            this.groupBoxStation.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxLines
            // 
            this.groupBoxLines.Controls.Add(this.textBoxNumberLine);
            this.groupBoxLines.Controls.Add(this.buttonLine);
            this.groupBoxLines.Controls.Add(this.labelNumberLine);
            this.groupBoxLines.Location = new System.Drawing.Point(12, 12);
            this.groupBoxLines.Name = "groupBoxLines";
            this.groupBoxLines.Size = new System.Drawing.Size(200, 100);
            this.groupBoxLines.TabIndex = 0;
            this.groupBoxLines.TabStop = false;
            this.groupBoxLines.Text = "Linie";
            // 
            // textBoxNumberLine
            // 
            this.textBoxNumberLine.Location = new System.Drawing.Point(48, 49);
            this.textBoxNumberLine.Name = "textBoxNumberLine";
            this.textBoxNumberLine.Size = new System.Drawing.Size(100, 20);
            this.textBoxNumberLine.TabIndex = 2;
            // 
            // buttonLine
            // 
            this.buttonLine.Location = new System.Drawing.Point(62, 71);
            this.buttonLine.Name = "buttonLine";
            this.buttonLine.Size = new System.Drawing.Size(75, 23);
            this.buttonLine.TabIndex = 1;
            this.buttonLine.Text = "Stwórz linię";
            this.buttonLine.UseVisualStyleBackColor = true;
            this.buttonLine.Click += new System.EventHandler(this.buttonLine_Click);
            // 
            // labelNumberLine
            // 
            this.labelNumberLine.AutoSize = true;
            this.labelNumberLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelNumberLine.Location = new System.Drawing.Point(56, 26);
            this.labelNumberLine.Name = "labelNumberLine";
            this.labelNumberLine.Size = new System.Drawing.Size(81, 20);
            this.labelNumberLine.TabIndex = 0;
            this.labelNumberLine.Text = "Numer linii";
            // 
            // groupBoxStation
            // 
            this.groupBoxStation.Controls.Add(this.buttonStation);
            this.groupBoxStation.Controls.Add(this.labelName);
            this.groupBoxStation.Controls.Add(this.textBoxStation);
            this.groupBoxStation.Location = new System.Drawing.Point(12, 144);
            this.groupBoxStation.Name = "groupBoxStation";
            this.groupBoxStation.Size = new System.Drawing.Size(200, 100);
            this.groupBoxStation.TabIndex = 1;
            this.groupBoxStation.TabStop = false;
            this.groupBoxStation.Text = "Stacje";
            // 
            // textBoxStation
            // 
            this.textBoxStation.Location = new System.Drawing.Point(48, 50);
            this.textBoxStation.Name = "textBoxStation";
            this.textBoxStation.Size = new System.Drawing.Size(100, 20);
            this.textBoxStation.TabIndex = 0;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelName.Location = new System.Drawing.Point(51, 16);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(97, 20);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "Nazwa stacji";
            // 
            // buttonStation
            // 
            this.buttonStation.Location = new System.Drawing.Point(55, 76);
            this.buttonStation.Name = "buttonStation";
            this.buttonStation.Size = new System.Drawing.Size(89, 23);
            this.buttonStation.TabIndex = 3;
            this.buttonStation.Text = "Stwórz stację";
            this.buttonStation.UseVisualStyleBackColor = true;
            this.buttonStation.Click += new System.EventHandler(this.buttonStation_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBoxStation);
            this.Controls.Add(this.groupBoxLines);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.groupBoxLines.ResumeLayout(false);
            this.groupBoxLines.PerformLayout();
            this.groupBoxStation.ResumeLayout(false);
            this.groupBoxStation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxLines;
        private System.Windows.Forms.TextBox textBoxNumberLine;
        private System.Windows.Forms.Button buttonLine;
        private System.Windows.Forms.Label labelNumberLine;
        private System.Windows.Forms.GroupBox groupBoxStation;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxStation;
        private System.Windows.Forms.Button buttonStation;
    }
}

