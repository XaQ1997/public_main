﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Line
    {
        protected int number;
        protected readonly List<Station> stationList=new List<Station>();

        public Line(int nr)
        {
            number = nr;
        }

        /// <summary>
        /// Metoda zwracająca numer linii
        /// </summary>
        /// <returns></returns>
        public int GetNumber()
        {
            return number;
        }

        /// <summary>
        /// Metoda zwracająca nazwę wybranej stacji leżącej na tej linii
        /// </summary>
        /// <param name="iter"></param>
        /// <returns></returns>
        public string GetStation(int iter)
        {
            return stationList[iter].GetName();
        }
    }
}
