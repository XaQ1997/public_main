﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Truck
    {
        private int freeSeats, occupiedSeats, number;
        private readonly List<Passager> passagerList = new List<Passager>();

        /// <summary>
        /// Metoda zwracająca ilość wolnych miejsc
        /// </summary>
        /// <returns></returns>
        public int GetFreeSeats()
        {
            return freeSeats;
        }

        /// <summary>
        /// Metoda zwracająca ilość zajętych miejsc
        /// </summary>
        /// <returns></returns>
        public int GetOccupiedSeats()
        {
            return occupiedSeats;
        }

        /// <summary>
        /// Metoda zwracająca numer wagonu
        /// </summary>
        /// <returns></returns>
        public int GetNumber()
        {
            return number;
        }

        /// <summary>
        /// Metoda sprawdzająca, czy w wagonie nie ma wolnego miejsca
        /// </summary>
        /// <returns></returns>
        public bool IsFreeSeats()
        {
            if(GetFreeSeats()==0||GetOccupiedSeats()==6)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Pasażer wsiada do wagonu
        /// </summary>
        /// <param name="passager"></param>
        public void PassagerIn(Passager passager)
        {
            freeSeats--;
            occupiedSeats++;
            passagerList.Add(passager);
        }

        /// <summary>
        /// Pasażer wysiada z pociągu
        /// </summary>
        /// <param name="passager"></param>
        public void PassagerOut(Passager passager)
        {
            freeSeats++;
            occupiedSeats--;
            passagerList.Remove(passager);
        }
    }
}
