﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KsaweryWawrzyniaLabk7Zadanie.Models;
using KsaweryWawrzyniaLabk7Zadanie.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace KsaweryWawrzyniaLabk7Zadanie.Controllers
{
    [Route("api/pizza")]
    [ApiController]
    public class HamburgerController : ControllerBase
    {
        private IHamburgerService hamburgerService;

        public HamburgerController(IHamburgerService _hamburgerService)
        {
            hamburgerService = _hamburgerService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var hamburgers = hamburgerService.Get();
            return Ok(hamburgers);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Hamburger hamburger)
        {
            var id = hamburgerService.Post(hamburger);
            return Ok(id);
        }

        [HttpPut]
        [Route("{id:int}")]
        public IActionResult Put([FromBody] Hamburger hamburger, [FromRoute] int id)
        {
            bool isSuccessfulUpdate = hamburgerService.Put(hamburger, id);
            if (isSuccessfulUpdate)
            {
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IActionResult Delete([FromRoute] int id)
        {
            bool isDeleteSuccess = hamburgerService.Delete(id);
            if (isDeleteSuccess)
            {
                return NoContent();
            }
            else
            {
                return BadRequest();
            }
        }
    }
}