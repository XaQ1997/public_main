﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KsaweryWawrzyniaLabk7Zadanie.Models;
using KsaweryWawrzyniaLabk7Zadanie.Services;
using Microsoft.AspNetCore.Mvc;

namespace KsaweryWawrzyniaLabk7Zadanie.Controllers
{
    [Route("api/pizza")]
    [ApiController]
    public class PizzaController : ControllerBase
    {
        private IPizzaService pizzaService;

        public PizzaController(IPizzaService _pizzaService)
        {
            pizzaService = _pizzaService;
        }

        [HttpGet]
        public IActionResult Get()
        {
            var pizzas = pizzaService.Get();
            return Ok(pizzas);
        }

        [HttpPost]
        public IActionResult Post([FromBody] Pizza pizza)
        {
            var id = pizzaService.Post(pizza);
            return Ok(id);
        }

        [HttpPut]
        [Route("{id:int}")]
        public IActionResult Put([FromBody] Pizza pizza, [FromRoute] int id)
        {
            bool isSuccessfulUpdate = pizzaService.Put(pizza, id);
            if (isSuccessfulUpdate)
            {
                return NoContent();
            }
            else
            {
                return NotFound();
            }
        }

        [HttpDelete]
        [Route("{id:int}")]
        public IActionResult Delete([FromRoute] int id)
        {
            bool isDeleteSuccess = pizzaService.Delete(id);
            if(isDeleteSuccess)
            {
                return NoContent();
            }
            else
            {
                return BadRequest();
            }
        }
    }
}