﻿using KsaweryWawrzyniaLabk7Zadanie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KsaweryWawrzyniaLabk7Zadanie.Services
{
    public class HamburgerService:IHamburgerService
    {
        private List<Hamburger> hamburgers = new List<Hamburger>();

        public List<Hamburger> Get()
        {
            return hamburgers;
        }

        public int Post(Hamburger hamburger)
        {
            int id;
            if (hamburgers.Count() == 0)
            {
                id = 0;
                hamburger.Id = id;
            }
            else
            {
                id = hamburgers.Max(x => x.Id);
                hamburger.Id = ++id;
            }
            hamburgers.Add(hamburger);
            return id;
        }

        public bool Put(Hamburger hamburger, int id)
        {
            var HamburgerToUpdate = hamburgers.Where(x => x.Equals(id)).SingleOrDefault();
            if (HamburgerToUpdate == null)
            {
                return false;
            }
            HamburgerToUpdate.Name = hamburger.Name;
            HamburgerToUpdate.Description = hamburger.Description;
            HamburgerToUpdate.Cost = hamburger.Cost;
            return true;
        }

        public bool Delete(int id)
        {
            var hamburger = hamburgers.Where(x => x.Equals(id)).SingleOrDefault();
            if (hamburger == null)
            {
                return false;
            }
            hamburgers.Remove(hamburger);
            return true;
        }
    }
}
