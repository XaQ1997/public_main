﻿using KsaweryWawrzyniaLabk7Zadanie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KsaweryWawrzyniaLabk7Zadanie.Services
{
    interface IPizzaService
    {
        List<Pizza> Get();
        int Post(Pizza pizza);
        bool Put(Pizza pizza, int id);
        bool Delete(int id);
    }
}
