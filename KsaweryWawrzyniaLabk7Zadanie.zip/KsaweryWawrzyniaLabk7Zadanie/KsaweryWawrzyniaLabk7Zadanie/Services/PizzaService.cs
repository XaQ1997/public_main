﻿using KsaweryWawrzyniaLabk7Zadanie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KsaweryWawrzyniaLabk7Zadanie.Services
{
    public class PizzaService:IPizzaService
    {
        private List<Pizza> pizzas = new List<Pizza>();

        public List<Pizza> Get()
        {
            return pizzas;
        }

        public int Post(Pizza pizza)
        {
            int id;
            if(pizzas.Count()==0)
            {
                id = 0;
                pizza.Id = id;
            }
            else
            {
                id = pizzas.Max(x => x.Id);
                pizza.Id = ++id;
            }
            pizzas.Add(pizza);
            return id;
        }

        public bool Put(Pizza pizza, int id)
        {
            var PizzaToUpdate = pizzas.Where(x => x.Equals(id)).SingleOrDefault();
            if(PizzaToUpdate==null)
            {
                return false;
            }
            PizzaToUpdate.Name = pizza.Name;
            PizzaToUpdate.Description = pizza.Description;
            PizzaToUpdate.Cost = pizza.Cost;
            return true;
        }

        public bool Delete(int id)
        {
            var pizza = pizzas.Where(x => x.Equals(id)).SingleOrDefault();
            if(pizza==null)
            {
                return false;
            }
            pizzas.Remove(pizza);
            return true;
        }
    }
}
