﻿using KsaweryWawrzyniaLabk7Zadanie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KsaweryWawrzyniaLabk7Zadanie.Services
{
    interface IHamburgerService
    {        List<Hamburger> Get();
        int Post(Hamburger hamburger);
        bool Put(Hamburger hamburger, int id);
        bool Delete(int id);
    }
}
