﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab4Zadanie.Models
{
    class Sportman
    {
        [Key]

        public int Id { get; set; }

        [Required]
        [DisplayName("Imię sportowca")]

        public string FirstName { get; set; }

        [Required(ErrorMessage = "Pole nazwisko jest puste")]
        [DisplayName("Nazwisko sportowca")]

        public string Surname { get; set; }

        [DisplayName("Dyscyplina")]
        [ForeignKey("SportName")]

        public string SportName { get; set; }

        [DisplayName("Miasto")]
        [ForeignKey("CityName")]

        public string CityName { get; set; }

        [DisplayName("Kraj")]
        [ForeignKey("CountryName")]

        public string CountryName { get; set; }
    }
}
