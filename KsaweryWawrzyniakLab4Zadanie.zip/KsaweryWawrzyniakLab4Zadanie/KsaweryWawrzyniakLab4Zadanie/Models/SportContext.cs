﻿using System.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab4Zadanie.Models
{
    class SportContext:DbContext
    {
        public DbSet<Country> Countries;
        public DbSet<Sportman> Sportmen;
        public DbSet<Sport> Sports;
        public DbSet<City> Cities;
        public DbSet<SportObject> SportObjects;
    }
}
