﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace KsaweryWawrzyniakLab4Zadanie.Models
{
    public class Sport
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [DisplayName("Nazwa sportu")]
        public string Name { get; set; }
    }
}