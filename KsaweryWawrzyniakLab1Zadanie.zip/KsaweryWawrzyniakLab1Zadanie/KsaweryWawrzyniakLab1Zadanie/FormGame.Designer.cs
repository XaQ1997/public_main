﻿namespace KsaweryWawrzyniakLab1Zadanie
{
    partial class FormGame
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormGame));
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.labelSpaceCount = new System.Windows.Forms.Label();
            this.labelFoodCount = new System.Windows.Forms.Label();
            this.labelPopulationCount = new System.Windows.Forms.Label();
            this.labelEnergyCount = new System.Windows.Forms.Label();
            this.labelMatteryCount = new System.Windows.Forms.Label();
            this.labelSpace = new System.Windows.Forms.Label();
            this.labelFood = new System.Windows.Forms.Label();
            this.labelPopulation = new System.Windows.Forms.Label();
            this.labelEnergy = new System.Windows.Forms.Label();
            this.labelMattery = new System.Windows.Forms.Label();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.eventLog = new System.Diagnostics.EventLog();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.eventLog)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer1
            // 
            resources.ApplyResources(this.splitContainer1, "splitContainer1");
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.splitContainer1.Panel1.ForeColor = System.Drawing.Color.White;
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.splitContainer1.Panel2.Controls.Add(this.labelSpaceCount);
            this.splitContainer1.Panel2.Controls.Add(this.labelFoodCount);
            this.splitContainer1.Panel2.Controls.Add(this.labelPopulationCount);
            this.splitContainer1.Panel2.Controls.Add(this.labelEnergyCount);
            this.splitContainer1.Panel2.Controls.Add(this.labelMatteryCount);
            this.splitContainer1.Panel2.Controls.Add(this.labelSpace);
            this.splitContainer1.Panel2.Controls.Add(this.labelFood);
            this.splitContainer1.Panel2.Controls.Add(this.labelPopulation);
            this.splitContainer1.Panel2.Controls.Add(this.labelEnergy);
            this.splitContainer1.Panel2.Controls.Add(this.labelMattery);
            this.splitContainer1.Panel2.Controls.Add(this.splitter1);
            // 
            // labelSpaceCount
            // 
            resources.ApplyResources(this.labelSpaceCount, "labelSpaceCount");
            this.labelSpaceCount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelSpaceCount.Name = "labelSpaceCount";
            this.labelSpaceCount.Click += new System.EventHandler(this.labelSpaceCount_Click);
            // 
            // labelFoodCount
            // 
            resources.ApplyResources(this.labelFoodCount, "labelFoodCount");
            this.labelFoodCount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelFoodCount.Name = "labelFoodCount";
            this.labelFoodCount.Click += new System.EventHandler(this.labelFoodCount_Click);
            // 
            // labelPopulationCount
            // 
            resources.ApplyResources(this.labelPopulationCount, "labelPopulationCount");
            this.labelPopulationCount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelPopulationCount.Name = "labelPopulationCount";
            this.labelPopulationCount.Click += new System.EventHandler(this.labelPopulationCount_Click);
            // 
            // labelEnergyCount
            // 
            resources.ApplyResources(this.labelEnergyCount, "labelEnergyCount");
            this.labelEnergyCount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelEnergyCount.Name = "labelEnergyCount";
            this.labelEnergyCount.Click += new System.EventHandler(this.labelEnergyCount_Click);
            // 
            // labelMatteryCount
            // 
            resources.ApplyResources(this.labelMatteryCount, "labelMatteryCount");
            this.labelMatteryCount.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelMatteryCount.Name = "labelMatteryCount";
            this.labelMatteryCount.Click += new System.EventHandler(this.labelMatteryCount_Click);
            // 
            // labelSpace
            // 
            resources.ApplyResources(this.labelSpace, "labelSpace");
            this.labelSpace.BackColor = System.Drawing.Color.Black;
            this.labelSpace.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelSpace.ForeColor = System.Drawing.Color.White;
            this.labelSpace.Name = "labelSpace";
            // 
            // labelFood
            // 
            resources.ApplyResources(this.labelFood, "labelFood");
            this.labelFood.BackColor = System.Drawing.Color.Lime;
            this.labelFood.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelFood.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.labelFood.Name = "labelFood";
            // 
            // labelPopulation
            // 
            resources.ApplyResources(this.labelPopulation, "labelPopulation");
            this.labelPopulation.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.labelPopulation.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelPopulation.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.labelPopulation.Name = "labelPopulation";
            // 
            // labelEnergy
            // 
            resources.ApplyResources(this.labelEnergy, "labelEnergy");
            this.labelEnergy.BackColor = System.Drawing.Color.Blue;
            this.labelEnergy.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelEnergy.ForeColor = System.Drawing.Color.Yellow;
            this.labelEnergy.Name = "labelEnergy";
            // 
            // labelMattery
            // 
            resources.ApplyResources(this.labelMattery, "labelMattery");
            this.labelMattery.BackColor = System.Drawing.Color.Olive;
            this.labelMattery.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.labelMattery.ForeColor = System.Drawing.Color.Cyan;
            this.labelMattery.Name = "labelMattery";
            // 
            // splitter1
            // 
            this.splitter1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.splitter1, "splitter1");
            this.splitter1.Name = "splitter1";
            this.splitter1.TabStop = false;
            // 
            // eventLog
            // 
            this.eventLog.SynchronizingObject = this;
            this.eventLog.EntryWritten += new System.Diagnostics.EntryWrittenEventHandler(this.eventLog_EntryWritten);
            // 
            // FormGame
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.splitContainer1);
            this.Name = "FormGame";
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.eventLog)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.Label labelSpaceCount;
        private System.Windows.Forms.Label labelFoodCount;
        private System.Windows.Forms.Label labelPopulationCount;
        private System.Windows.Forms.Label labelEnergyCount;
        private System.Windows.Forms.Label labelMatteryCount;
        private System.Windows.Forms.Label labelSpace;
        private System.Windows.Forms.Label labelFood;
        private System.Windows.Forms.Label labelPopulation;
        private System.Windows.Forms.Label labelEnergy;
        private System.Windows.Forms.Label labelMattery;
        private System.Diagnostics.EventLog eventLog;
    }
}

