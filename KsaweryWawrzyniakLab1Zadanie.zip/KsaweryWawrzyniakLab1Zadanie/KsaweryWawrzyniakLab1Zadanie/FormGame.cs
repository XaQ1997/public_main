﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KsaweryWawrzyniakLab1Zadanie
{
    public partial class FormGame : Form
    {
        static int velocityMattery = 1;
        static int c = 300; // Jest to prędkość światła
        static int velocityEnergy = velocityMattery * c * c;
        static int velocityPopulation = 2;
        static int velocityFood = 2;
        static int velocity = 1;
        static int r = 1200; // Jest to promień wszechświata

        public FormGame()
        {
            InitializeComponent();
        }

        private void labelMatteryCount_Click(object sender, EventArgs e) //Ta labelka określa ilość materii posiadanej przez gracza
        {
            for(int i=0; ;i+=velocityMattery)
            {
                labelMatteryCount.Text = i.ToString();
                Thread.Sleep(1000);
                labelMatteryCount.Refresh();
                labelMatteryCount.Update();
            }
        }

        private void labelEnergyCount_Click(object sender, EventArgs e) //Ta labelka określa ilość energii posiadanej przez gracza
        {
            for (int i = 0; ; i += velocityEnergy)
            {
                labelEnergyCount.Text = i.ToString();
                Thread.Sleep(1000);
                labelEnergyCount.Refresh();
                labelEnergyCount.Update();
            }
        }

        private void labelPopulationCount_Click(object sender, EventArgs e) //Ta labelka określa populację gracza
        {
            for (int i = 1000; ; i *= velocityPopulation)
            {
                labelPopulationCount.Text = i.ToString();
                Thread.Sleep(1000);
                labelPopulationCount.Refresh();
                labelPopulationCount.Update();
            }
        }

        private void labelFoodCount_Click(object sender, EventArgs e) //Ta labelka określa ilość żywności posiadanej przez gracza
        {
            for (int i = 100; ; i *= velocityFood)
            {
                labelFoodCount.Text = i.ToString();
                Thread.Sleep(1000);
                labelFoodCount.Refresh();
                labelFoodCount.Update();
            }
        }

        private void labelSpaceCount_Click(object sender, EventArgs e) //Ta labelka określa terytorium gracza
        {
            for (int i = 900; ; i += velocity)
            {
                labelMatteryCount.Text = i.ToString();
                Thread.Sleep(1000);
                labelSpaceCount.Refresh();
                labelSpaceCount.Update();
            }
        }

        private void eventLog_EntryWritten(object sender, System.Diagnostics.EntryWrittenEventArgs e) //To jest eventLog
        {
            var random = new Random();
            for(int i=0; ;++i)
            {
                random.Next(0, 3);
                Thread.Sleep(1000);
                if (Convert.ToInt32(random) == 1) //jeśli random to 1, to mamy zmianę prędkości światła
                {
                    var rand = new Random();
                    rand.Next(-c, c);
                    c += Convert.ToInt32(rand);
                }
                else if (Convert.ToInt32(random) == 2) //Jeśli random to 2, to gracz odkrył przejście (typu czarna dziura) pomiędzy dwoma miejscami
                    velocity *= 2;
                else if (Convert.ToInt32(random) == 3) //Jeśli random to 3, to gracz ma albo kryzys gospodarczy albo jego ożywienie
                {
                    var Rand = new Random();
                    velocityFood += Convert.ToInt32(Rand);
                }
            }
        }
    }
}