﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using KsaweryWawrzyniakLab6._2.Models;

namespace KsaweryWawrzyniakLab6._2.Controllers
{
    public class HomeController : Controller
    {
        List<CarViewModel> cars;

        public HomeController()
        {
            cars = new List<CarViewModel>();
            cars.Add(new CarViewModel("Focus", "Ford", 72000, "~/wwwroot/images/focus.png"));
            cars.Add(new CarViewModel("Golf", "Volkswagen", 80000, ""));
            //cars.Add(new CarViewModel());
        }
        public IActionResult GetAllCar()
        {
            return View(cars);
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Name()
        {
            string name = "Ksawery";
            return View(name);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult GetListOfModels()
        {
            List<string> models=new List<string>();
            foreach(var car in cars)
            {
                models.Add(car.Model);
            }
            return View(models);
        }

        [HttpGet]
        public IActionResult ContactForm()
        {
            return View();
        }

        [HttpPost]
        public IActionResult ContactForm(ContactFormViewModel userData)
        {
            string fullName = userData.FirstName + " " + userData.LastName;
            ViewBag.UserName = fullName;
            return View("GreetingsForm");
        }

        public IActionResult GetCarByModel(string model)
        {
            var car=cars.Where(c => c.Model == model).FirstOrDefault();
            return View(car);
        }
    }
}
