﻿using KsaweryWawrzyniakLab4Zadanie.Models;
using KsaweryWawrzyniakLab4Zadanie.Repositories;
using System;
using System.Windows.Forms;

namespace KsaweryWawrzyniakLab4Zadanie
{
    public partial class FormMain : Form
    {
        private ISportGeneric<Sport> _sports;
        private ISportGeneric<Sportman> _sportmen;
        private ISportGeneric<Country> _countries;
        private ISportGeneric<City> _cities;
        private ISportGeneric<SportObject> _sportObjects;
        public FormMain()
        {
            InitializeComponent();
            _cities = new SportGeneric<City>();
            _countries = new SportGeneric<Country>();
            _sportmen = new SportGeneric<Sportman>();
            _sportObjects = new SportGeneric<SportObject>();
            _sports = new SportGeneric<Sport>();
            LoadCountries();
            LoadSportObjects();
            LoadSportmen();
        }

        private void LoadSportmen()
        {
            dataGridViewSportmen.DataSource = _sportmen.GetAll();
        }

        private void LoadSportObjects()
        {
            dataGridViewSportObjects.DataSource = _sportObjects.GetAll();
        }

        private void LoadCountries()
        {
            dataGridViewCountries.DataSource = _countries.GetAll();
        }

        private void buttonCreateSportObject_Click(object sender, EventArgs e)
        {
            TextBox textbox = new TextBox();
            textbox.Show();
            SportObject entity = new SportObject();
            entity.Name = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.FanCount = Int32.Parse(textbox.Text);
            textbox = new TextBox();
            textbox.Show();
            entity.SportName = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.CityName = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.CountryName = textbox.Text;
            _sportObjects.Create(entity);
        }

        private void buttonRemoveSportObject_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            _sportObjects.DeleteById(Int32.Parse(textBox.Text));
        }

        private void buttonUpdateSportObject_Click(object sender, EventArgs e)
        {

            TextBox textbox = new TextBox();
            textbox.Show();
            SportObject entity = new SportObject();
            entity.Name = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.FanCount = Int32.Parse(textbox.Text);
            textbox = new TextBox();
            textbox.Show();
            entity.SportName = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.CityName = textbox.Text;
            textbox = new TextBox();
            textbox.Show();
            entity.CountryName = textbox.Text;
            _sportObjects.Update(entity);
        }

        private void buttonSaveSportObject_Click(object sender, EventArgs e)
        {
            _sportObjects.Save();
        }

        private void buttonCreateCountry_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            Country entity = new Country();
            entity.Name = textBox.Text;
            _countries.Create(entity);
        }

        private void buttonRemoveCountry_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            _countries.DeleteById(Int32.Parse(textBox.Text));
        }

        private void buttonUpdateCountry_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            Country entity = new Country();
            entity.Name = textBox.Text;
            _countries.Update(entity);
        }

        private void buttonSaveCountry_Click(object sender, EventArgs e)
        {
            _countries.Save();
        }

        private void buttonCreateSportman_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            Sportman entity = new Sportman();
            entity.FirstName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.Surname = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.SportName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.CityName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.CountryName = textBox.Text;
            _sportmen.Create(entity);
        }

        private void buttonRemoveSportman_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            _sportmen.DeleteById(Int32.Parse(textBox.Text));
        }

        private void buttonUpdateSportman_Click(object sender, EventArgs e)
        {
            TextBox textBox = new TextBox();
            textBox.Show();
            Sportman entity = new Sportman();
            entity.FirstName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.Surname = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.SportName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.CityName = textBox.Text;
            textBox = new TextBox();
            textBox.Show();
            entity.CountryName = textBox.Text;
            _sportmen.Update(entity);
        }

        private void buttonSaveSportman_Click(object sender, EventArgs e)
        {
            _sportmen.Save();
        }
    }
}
