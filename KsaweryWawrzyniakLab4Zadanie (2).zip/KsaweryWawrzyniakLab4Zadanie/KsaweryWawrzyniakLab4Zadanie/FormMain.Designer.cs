﻿namespace KsaweryWawrzyniakLab4Zadanie
{
    partial class FormMain
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewSportObjects = new System.Windows.Forms.DataGridView();
            this.dataGridViewSportmen = new System.Windows.Forms.DataGridView();
            this.dataGridViewCountries = new System.Windows.Forms.DataGridView();
            this.buttonPreviousSportObject = new System.Windows.Forms.Button();
            this.buttonNextSportObject = new System.Windows.Forms.Button();
            this.buttonCreateSportObject = new System.Windows.Forms.Button();
            this.buttonRemoveSportObject = new System.Windows.Forms.Button();
            this.buttonUpdateSportObject = new System.Windows.Forms.Button();
            this.buttonSaveSportObject = new System.Windows.Forms.Button();
            this.buttonPreviousCountry = new System.Windows.Forms.Button();
            this.buttonNextCountry = new System.Windows.Forms.Button();
            this.buttonCreateCountry = new System.Windows.Forms.Button();
            this.buttonRemoveCountry = new System.Windows.Forms.Button();
            this.buttonUpdateCountry = new System.Windows.Forms.Button();
            this.buttonSaveCountry = new System.Windows.Forms.Button();
            this.buttonPreviousSportman = new System.Windows.Forms.Button();
            this.buttonNextSportman = new System.Windows.Forms.Button();
            this.buttonCreateSportman = new System.Windows.Forms.Button();
            this.buttonRemoveSportman = new System.Windows.Forms.Button();
            this.buttonUpdateSportman = new System.Windows.Forms.Button();
            this.buttonSaveSportman = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSportObjects)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSportmen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCountries)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewSportObjects
            // 
            this.dataGridViewSportObjects.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSportObjects.Location = new System.Drawing.Point(631, 39);
            this.dataGridViewSportObjects.Name = "dataGridViewSportObjects";
            this.dataGridViewSportObjects.RowHeadersWidth = 51;
            this.dataGridViewSportObjects.RowTemplate.Height = 24;
            this.dataGridViewSportObjects.Size = new System.Drawing.Size(516, 326);
            this.dataGridViewSportObjects.TabIndex = 0;
            // 
            // dataGridViewSportmen
            // 
            this.dataGridViewSportmen.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewSportmen.Location = new System.Drawing.Point(42, 560);
            this.dataGridViewSportmen.Name = "dataGridViewSportmen";
            this.dataGridViewSportmen.RowHeadersWidth = 51;
            this.dataGridViewSportmen.RowTemplate.Height = 24;
            this.dataGridViewSportmen.Size = new System.Drawing.Size(1105, 363);
            this.dataGridViewSportmen.TabIndex = 1;
            // 
            // dataGridViewCountries
            // 
            this.dataGridViewCountries.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewCountries.Location = new System.Drawing.Point(42, 39);
            this.dataGridViewCountries.Name = "dataGridViewCountries";
            this.dataGridViewCountries.RowHeadersWidth = 51;
            this.dataGridViewCountries.RowTemplate.Height = 24;
            this.dataGridViewCountries.Size = new System.Drawing.Size(487, 326);
            this.dataGridViewCountries.TabIndex = 2;
            // 
            // buttonPreviousSportObject
            // 
            this.buttonPreviousSportObject.Location = new System.Drawing.Point(631, 392);
            this.buttonPreviousSportObject.Name = "buttonPreviousSportObject";
            this.buttonPreviousSportObject.Size = new System.Drawing.Size(108, 51);
            this.buttonPreviousSportObject.TabIndex = 3;
            this.buttonPreviousSportObject.Text = "Poprzedni";
            this.buttonPreviousSportObject.UseVisualStyleBackColor = true;
            // 
            // buttonNextSportObject
            // 
            this.buttonNextSportObject.Location = new System.Drawing.Point(827, 392);
            this.buttonNextSportObject.Name = "buttonNextSportObject";
            this.buttonNextSportObject.Size = new System.Drawing.Size(104, 51);
            this.buttonNextSportObject.TabIndex = 4;
            this.buttonNextSportObject.Text = "Następny";
            this.buttonNextSportObject.UseVisualStyleBackColor = true;
            // 
            // buttonCreateSportObject
            // 
            this.buttonCreateSportObject.Location = new System.Drawing.Point(1043, 392);
            this.buttonCreateSportObject.Name = "buttonCreateSportObject";
            this.buttonCreateSportObject.Size = new System.Drawing.Size(104, 51);
            this.buttonCreateSportObject.TabIndex = 5;
            this.buttonCreateSportObject.Text = "Stwórz";
            this.buttonCreateSportObject.UseVisualStyleBackColor = true;
            this.buttonCreateSportObject.Click += new System.EventHandler(this.buttonCreateSportObject_Click);
            // 
            // buttonRemoveSportObject
            // 
            this.buttonRemoveSportObject.Location = new System.Drawing.Point(631, 472);
            this.buttonRemoveSportObject.Name = "buttonRemoveSportObject";
            this.buttonRemoveSportObject.Size = new System.Drawing.Size(108, 54);
            this.buttonRemoveSportObject.TabIndex = 6;
            this.buttonRemoveSportObject.Text = "Usuń";
            this.buttonRemoveSportObject.UseVisualStyleBackColor = true;
            this.buttonRemoveSportObject.Click += new System.EventHandler(this.buttonRemoveSportObject_Click);
            // 
            // buttonUpdateSportObject
            // 
            this.buttonUpdateSportObject.Location = new System.Drawing.Point(827, 472);
            this.buttonUpdateSportObject.Name = "buttonUpdateSportObject";
            this.buttonUpdateSportObject.Size = new System.Drawing.Size(104, 54);
            this.buttonUpdateSportObject.TabIndex = 7;
            this.buttonUpdateSportObject.Text = "Popraw";
            this.buttonUpdateSportObject.UseVisualStyleBackColor = true;
            this.buttonUpdateSportObject.Click += new System.EventHandler(this.buttonUpdateSportObject_Click);
            // 
            // buttonSaveSportObject
            // 
            this.buttonSaveSportObject.Location = new System.Drawing.Point(1043, 472);
            this.buttonSaveSportObject.Name = "buttonSaveSportObject";
            this.buttonSaveSportObject.Size = new System.Drawing.Size(104, 54);
            this.buttonSaveSportObject.TabIndex = 8;
            this.buttonSaveSportObject.Text = "Zapisz";
            this.buttonSaveSportObject.UseVisualStyleBackColor = true;
            this.buttonSaveSportObject.Click += new System.EventHandler(this.buttonSaveSportObject_Click);
            // 
            // buttonPreviousCountry
            // 
            this.buttonPreviousCountry.Location = new System.Drawing.Point(42, 392);
            this.buttonPreviousCountry.Name = "buttonPreviousCountry";
            this.buttonPreviousCountry.Size = new System.Drawing.Size(108, 51);
            this.buttonPreviousCountry.TabIndex = 9;
            this.buttonPreviousCountry.Text = "Poprzedni";
            this.buttonPreviousCountry.UseVisualStyleBackColor = true;
            // 
            // buttonNextCountry
            // 
            this.buttonNextCountry.Location = new System.Drawing.Point(240, 392);
            this.buttonNextCountry.Name = "buttonNextCountry";
            this.buttonNextCountry.Size = new System.Drawing.Size(104, 51);
            this.buttonNextCountry.TabIndex = 10;
            this.buttonNextCountry.Text = "Następny";
            this.buttonNextCountry.UseVisualStyleBackColor = true;
            // 
            // buttonCreateCountry
            // 
            this.buttonCreateCountry.Location = new System.Drawing.Point(425, 392);
            this.buttonCreateCountry.Name = "buttonCreateCountry";
            this.buttonCreateCountry.Size = new System.Drawing.Size(104, 51);
            this.buttonCreateCountry.TabIndex = 11;
            this.buttonCreateCountry.Text = "Stwórz";
            this.buttonCreateCountry.UseVisualStyleBackColor = true;
            this.buttonCreateCountry.Click += new System.EventHandler(this.buttonCreateCountry_Click);
            // 
            // buttonRemoveCountry
            // 
            this.buttonRemoveCountry.Location = new System.Drawing.Point(42, 472);
            this.buttonRemoveCountry.Name = "buttonRemoveCountry";
            this.buttonRemoveCountry.Size = new System.Drawing.Size(108, 54);
            this.buttonRemoveCountry.TabIndex = 12;
            this.buttonRemoveCountry.Text = "Usuń";
            this.buttonRemoveCountry.UseVisualStyleBackColor = true;
            this.buttonRemoveCountry.Click += new System.EventHandler(this.buttonRemoveCountry_Click);
            // 
            // buttonUpdateCountry
            // 
            this.buttonUpdateCountry.Location = new System.Drawing.Point(240, 472);
            this.buttonUpdateCountry.Name = "buttonUpdateCountry";
            this.buttonUpdateCountry.Size = new System.Drawing.Size(104, 54);
            this.buttonUpdateCountry.TabIndex = 13;
            this.buttonUpdateCountry.Text = "Popraw";
            this.buttonUpdateCountry.UseVisualStyleBackColor = true;
            this.buttonUpdateCountry.Click += new System.EventHandler(this.buttonUpdateCountry_Click);
            // 
            // buttonSaveCountry
            // 
            this.buttonSaveCountry.Location = new System.Drawing.Point(425, 472);
            this.buttonSaveCountry.Name = "buttonSaveCountry";
            this.buttonSaveCountry.Size = new System.Drawing.Size(104, 54);
            this.buttonSaveCountry.TabIndex = 14;
            this.buttonSaveCountry.Text = "Zapisz";
            this.buttonSaveCountry.UseVisualStyleBackColor = true;
            this.buttonSaveCountry.Click += new System.EventHandler(this.buttonSaveCountry_Click);
            // 
            // buttonPreviousSportman
            // 
            this.buttonPreviousSportman.Location = new System.Drawing.Point(12, 943);
            this.buttonPreviousSportman.Name = "buttonPreviousSportman";
            this.buttonPreviousSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonPreviousSportman.TabIndex = 15;
            this.buttonPreviousSportman.Text = "Poprzedni";
            this.buttonPreviousSportman.UseVisualStyleBackColor = true;
            // 
            // buttonNextSportman
            // 
            this.buttonNextSportman.Location = new System.Drawing.Point(208, 943);
            this.buttonNextSportman.Name = "buttonNextSportman";
            this.buttonNextSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonNextSportman.TabIndex = 16;
            this.buttonNextSportman.Text = "Następny";
            this.buttonNextSportman.UseVisualStyleBackColor = true;
            // 
            // buttonCreateSportman
            // 
            this.buttonCreateSportman.Location = new System.Drawing.Point(404, 943);
            this.buttonCreateSportman.Name = "buttonCreateSportman";
            this.buttonCreateSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonCreateSportman.TabIndex = 17;
            this.buttonCreateSportman.Text = "Stwórz";
            this.buttonCreateSportman.UseVisualStyleBackColor = true;
            this.buttonCreateSportman.Click += new System.EventHandler(this.buttonCreateSportman_Click);
            // 
            // buttonRemoveSportman
            // 
            this.buttonRemoveSportman.Location = new System.Drawing.Point(600, 943);
            this.buttonRemoveSportman.Name = "buttonRemoveSportman";
            this.buttonRemoveSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonRemoveSportman.TabIndex = 18;
            this.buttonRemoveSportman.Text = "Usuń";
            this.buttonRemoveSportman.UseVisualStyleBackColor = true;
            this.buttonRemoveSportman.Click += new System.EventHandler(this.buttonRemoveSportman_Click);
            // 
            // buttonUpdateSportman
            // 
            this.buttonUpdateSportman.Location = new System.Drawing.Point(796, 943);
            this.buttonUpdateSportman.Name = "buttonUpdateSportman";
            this.buttonUpdateSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonUpdateSportman.TabIndex = 19;
            this.buttonUpdateSportman.Text = "Popraw";
            this.buttonUpdateSportman.UseVisualStyleBackColor = true;
            this.buttonUpdateSportman.Click += new System.EventHandler(this.buttonUpdateSportman_Click);
            // 
            // buttonSaveSportman
            // 
            this.buttonSaveSportman.Location = new System.Drawing.Point(992, 943);
            this.buttonSaveSportman.Name = "buttonSaveSportman";
            this.buttonSaveSportman.Size = new System.Drawing.Size(190, 80);
            this.buttonSaveSportman.TabIndex = 20;
            this.buttonSaveSportman.Text = "Zapisz";
            this.buttonSaveSportman.UseVisualStyleBackColor = true;
            this.buttonSaveSportman.Click += new System.EventHandler(this.buttonSaveSportman_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 1055);
            this.Controls.Add(this.buttonSaveSportman);
            this.Controls.Add(this.buttonUpdateSportman);
            this.Controls.Add(this.buttonRemoveSportman);
            this.Controls.Add(this.buttonCreateSportman);
            this.Controls.Add(this.buttonNextSportman);
            this.Controls.Add(this.buttonPreviousSportman);
            this.Controls.Add(this.buttonSaveCountry);
            this.Controls.Add(this.buttonUpdateCountry);
            this.Controls.Add(this.buttonRemoveCountry);
            this.Controls.Add(this.buttonCreateCountry);
            this.Controls.Add(this.buttonNextCountry);
            this.Controls.Add(this.buttonPreviousCountry);
            this.Controls.Add(this.buttonSaveSportObject);
            this.Controls.Add(this.buttonUpdateSportObject);
            this.Controls.Add(this.buttonRemoveSportObject);
            this.Controls.Add(this.buttonCreateSportObject);
            this.Controls.Add(this.buttonNextSportObject);
            this.Controls.Add(this.buttonPreviousSportObject);
            this.Controls.Add(this.dataGridViewCountries);
            this.Controls.Add(this.dataGridViewSportmen);
            this.Controls.Add(this.dataGridViewSportObjects);
            this.Name = "FormMain";
            this.Text = "FormMain";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSportObjects)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewSportmen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewCountries)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewSportObjects;
        private System.Windows.Forms.DataGridView dataGridViewSportmen;
        private System.Windows.Forms.DataGridView dataGridViewCountries;
        private System.Windows.Forms.Button buttonPreviousSportObject;
        private System.Windows.Forms.Button buttonNextSportObject;
        private System.Windows.Forms.Button buttonCreateSportObject;
        private System.Windows.Forms.Button buttonRemoveSportObject;
        private System.Windows.Forms.Button buttonUpdateSportObject;
        private System.Windows.Forms.Button buttonSaveSportObject;
        private System.Windows.Forms.Button buttonPreviousCountry;
        private System.Windows.Forms.Button buttonNextCountry;
        private System.Windows.Forms.Button buttonCreateCountry;
        private System.Windows.Forms.Button buttonRemoveCountry;
        private System.Windows.Forms.Button buttonUpdateCountry;
        private System.Windows.Forms.Button buttonSaveCountry;
        private System.Windows.Forms.Button buttonPreviousSportman;
        private System.Windows.Forms.Button buttonNextSportman;
        private System.Windows.Forms.Button buttonCreateSportman;
        private System.Windows.Forms.Button buttonRemoveSportman;
        private System.Windows.Forms.Button buttonUpdateSportman;
        private System.Windows.Forms.Button buttonSaveSportman;
    }
}

