﻿using KsaweryWawrzyniakLab4Zadanie.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab4Zadanie.Repositories
{
    class SportGeneric<T>:ISportGeneric<T> where T:class
    {
        private readonly SportContext _context;

        public SportGeneric()
        {
            _context = new SportContext();
        }

        public List<T> GetAll()
        {
            return _context.Set<T>().ToList();
        }

        public IQueryable<T> Get()
        {
            return _context.Set<T>().AsQueryable();
        }

        public T GetById(int id)
        {
            return _context.Set<T>().Find(id);
        }

        public void DeleteById(int id)
        {
            T entities=_context.Set<T>().Find(id);
            _context.Set<T>().Remove(entities);
        }

        public void Update(T entity)
        {
            _context.Entry(entity).CurrentValues.SetValues(entity);
            _context.SaveChanges();
        }

        public void Create(T entity)
        {
            _context.Set<T>().Add(entity);
        }

        public void Save()
        {
            _context.SaveChanges();
        }
    }
}
