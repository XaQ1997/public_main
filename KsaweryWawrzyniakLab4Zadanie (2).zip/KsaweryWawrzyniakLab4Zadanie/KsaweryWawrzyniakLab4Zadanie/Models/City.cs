﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KsaweryWawrzyniakLab4Zadanie.Models
{
    internal class City
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [DisplayName("Nazwa miasta")]
        public string Name { get; set; }

        [DisplayName("Państwo")]
        [ForeignKey("CountryName")]
        public string CountryName { get; set; }
    }
}