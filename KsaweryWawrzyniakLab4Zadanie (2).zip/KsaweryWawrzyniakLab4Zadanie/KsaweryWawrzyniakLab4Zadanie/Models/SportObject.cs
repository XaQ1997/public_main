﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KsaweryWawrzyniakLab4Zadanie.Models
{
    public class SportObject
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [DisplayName("Nazwa obiektu sportowego")]
        public string Name { get; set; }

        [DisplayName("Ilość maksymalna kibiców")]
        public int FanCount { get; set; }

        [DisplayName("Dyscyplina")]
        [ForeignKey("SportName")]
        public string SportName { get; set; }

        [DisplayName("Miasto")]
        [ForeignKey("CityName")]
        public string CityName { get; set; }

        [DisplayName("Kraj")]
        [ForeignKey("CountryName")]
        public string CountryName { get; set; }
    }
}