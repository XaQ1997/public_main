﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KsaweryWawrzyniakLab1
{
    public partial class FormMain : Form
    {
        public FormMain()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e) ///guzik startowy
        {

        }

        private void label1_Click(object sender, EventArgs e) ///przedstawienie sie
        {

        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e) ///guzik, ktory wylicza sume
        {
            int number = 0, leftNumber = 0, rightNumber = 0;
            leftNumber = Int32.Parse(textBoxCount.Text);
            rightNumber = Int32.Parse(textBoxCount2.Text);
            number = leftNumber + rightNumber;
            MessageBox.Show(number.ToString());
            if(number>30)
            {
                BackColor = Color.Aqua;
            }
        }

        private void textBoxCount_TextChanged(object sender, EventArgs e) ///pierwszy skladnik liczbowy
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e) ///drugi skladnik liczbowy
        {

        }

        private void button1_Click_1(object sender, EventArgs e) ///button wlaczajacy timera
        {
            timer.Interval = 1000;
            ///uruchomienie timera
            timer.Start();
            ///przesuwanie sie buttona
            int counter = 0;
            while(counter<=1000)
            {
                buttonTimer.Left += counter;
                counter++;
            }
        }

        private void timer_Tick(object sender, EventArgs e) ///timer odliczajacy po nacisnieciu buttonTimera
        { 

        }

        private void buttonNewWindow_Click(object sender, EventArgs e) ///button otwierajacy nowe okno
        {
            FormAbout formAbout = new FormAbout();
        }
    }
}
