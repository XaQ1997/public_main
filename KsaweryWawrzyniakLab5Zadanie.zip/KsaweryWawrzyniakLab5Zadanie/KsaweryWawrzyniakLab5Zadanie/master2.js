﻿const puzzleText = document.getElementById("puzzleText");
const boxes = document.querySelectorAll(".box");
const message = document.getElementById("message");

let isPlaying = true;
let colors = generateRandomColors();
let selectedColor;

//Metody definiujące kolor pudełka
function generateRandomColors() {
    let arr = [];
    for (let i = 0; i < boxes.length; ++i) {
        arr.push(randomColor());
    }
    return arr;
}

function randomColor() {
    let red = Math.floor(Math.random() * 256);
    let green = Math.floor(Math.random() * 256);
    let blue = Math.floor(Math.random() * 256);

    return `rgb(${red}, ${green}, ${blue})`;
}

//Metoda modyfikująca puzzleText
function setPuzzleText(colorArr) {
    selectedColor = Math.floor(Math.random() * colorArr.length);
    puzzleText.textContent = colorArr[selectedColor];
}

//Metoda modyfikująca kolor pudełek
function changeColor(colorArr) {
    for (let i = 0; i < boxes.length; ++i) {
        boxes[i].style.background = colorArr[i];
    }
}

//Wywołanie metod po wczytaniu strony
changeColor(colorArr);

for (let i = 0; i < boxes.length; ++i) {
    boxes[i].addEventListener('click', function (e) {
        if (isPlaying) {
            if (e.target.style.backgroundColor === colors[selectedColor]) {
                isPlaying = false;
                window.location = "page3.html";
            }
            else {
                message.textContent = 'Try again...';
                window.location = "index.html";
            }
        }
    });
}

setPuzzleText(colors);