﻿namespace KsaweryWawrzyniakLab1
{
    partial class FormMain
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.NameLabel = new System.Windows.Forms.Label();
            this.clickButton = new System.Windows.Forms.Button();
            this.buttonCount = new System.Windows.Forms.Button();
            this.textBoxCount = new System.Windows.Forms.TextBox();
            this.textBoxCount2 = new System.Windows.Forms.TextBox();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.buttonTimer = new System.Windows.Forms.Button();
            this.buttonNewWindow = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F);
            this.NameLabel.ForeColor = System.Drawing.Color.DarkGreen;
            this.NameLabel.Location = new System.Drawing.Point(137, 151);
            this.NameLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(505, 46);
            this.NameLabel.TabIndex = 0;
            this.NameLabel.Text = "KSAWERY WAWRZYNIAK";
            this.NameLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // clickButton
            // 
            this.clickButton.BackColor = System.Drawing.Color.Crimson;
            this.clickButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.clickButton.ForeColor = System.Drawing.Color.MediumAquamarine;
            this.clickButton.Location = new System.Drawing.Point(242, 215);
            this.clickButton.Margin = new System.Windows.Forms.Padding(6);
            this.clickButton.Name = "clickButton";
            this.clickButton.Size = new System.Drawing.Size(228, 98);
            this.clickButton.TabIndex = 2;
            this.clickButton.Text = "Click";
            this.clickButton.UseVisualStyleBackColor = false;
            this.clickButton.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonCount
            // 
            this.buttonCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonCount.Location = new System.Drawing.Point(451, 352);
            this.buttonCount.Name = "buttonCount";
            this.buttonCount.Size = new System.Drawing.Size(75, 23);
            this.buttonCount.TabIndex = 3;
            this.buttonCount.Text = "Count";
            this.buttonCount.UseVisualStyleBackColor = true;
            this.buttonCount.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBoxCount
            // 
            this.textBoxCount.Location = new System.Drawing.Point(266, 345);
            this.textBoxCount.Name = "textBoxCount";
            this.textBoxCount.Size = new System.Drawing.Size(160, 32);
            this.textBoxCount.TabIndex = 4;
            this.textBoxCount.TextChanged += new System.EventHandler(this.textBoxCount_TextChanged);
            // 
            // textBoxCount2
            // 
            this.textBoxCount2.Location = new System.Drawing.Point(266, 392);
            this.textBoxCount2.Name = "textBoxCount2";
            this.textBoxCount2.Size = new System.Drawing.Size(160, 32);
            this.textBoxCount2.TabIndex = 5;
            this.textBoxCount2.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // buttonTimer
            // 
            this.buttonTimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonTimer.Location = new System.Drawing.Point(12, 91);
            this.buttonTimer.Name = "buttonTimer";
            this.buttonTimer.Size = new System.Drawing.Size(75, 24);
            this.buttonTimer.TabIndex = 6;
            this.buttonTimer.Text = "Start!";
            this.buttonTimer.UseVisualStyleBackColor = true;
            this.buttonTimer.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // buttonNewWindow
            // 
            this.buttonNewWindow.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            this.buttonNewWindow.Location = new System.Drawing.Point(340, 45);
            this.buttonNewWindow.Name = "buttonNewWindow";
            this.buttonNewWindow.Size = new System.Drawing.Size(86, 23);
            this.buttonNewWindow.TabIndex = 7;
            this.buttonNewWindow.Text = "New WIndow";
            this.buttonNewWindow.UseVisualStyleBackColor = true;
            this.buttonNewWindow.Click += new System.EventHandler(this.buttonNewWindow_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 473);
            this.Controls.Add(this.buttonNewWindow);
            this.Controls.Add(this.buttonTimer);
            this.Controls.Add(this.textBoxCount2);
            this.Controls.Add(this.textBoxCount);
            this.Controls.Add(this.buttonCount);
            this.Controls.Add(this.clickButton);
            this.Controls.Add(this.NameLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.Load += new System.EventHandler(this.FormMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button clickButton;
        private System.Windows.Forms.Button buttonCount;
        private System.Windows.Forms.TextBox textBoxCount;
        private System.Windows.Forms.TextBox textBoxCount2;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button buttonTimer;
        private System.Windows.Forms.Button buttonNewWindow;
    }
}

