﻿namespace KsaweryWawrzyniakLab2Zadanie
{
    partial class FormMain
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBoxLines = new System.Windows.Forms.GroupBox();
            this.checkBoxCircullarLine = new System.Windows.Forms.CheckBox();
            this.textBoxLine = new System.Windows.Forms.TextBox();
            this.buttonLine = new System.Windows.Forms.Button();
            this.labelNumberLine = new System.Windows.Forms.Label();
            this.groupBoxStation = new System.Windows.Forms.GroupBox();
            this.buttonStation = new System.Windows.Forms.Button();
            this.labelName = new System.Windows.Forms.Label();
            this.textBoxStation = new System.Windows.Forms.TextBox();
            this.checkBoxInterchangeStation = new System.Windows.Forms.CheckBox();
            this.groupBoxTrain = new System.Windows.Forms.GroupBox();
            this.buttonCreate = new System.Windows.Forms.Button();
            this.radioButtonTruck = new System.Windows.Forms.RadioButton();
            this.radioButtonTrain = new System.Windows.Forms.RadioButton();
            this.textBoxTrain = new System.Windows.Forms.TextBox();
            this.textBoxTruck = new System.Windows.Forms.TextBox();
            this.labelTrain = new System.Windows.Forms.Label();
            this.labelTruck = new System.Windows.Forms.Label();
            this.groupBoxStationLine = new System.Windows.Forms.GroupBox();
            this.buttonNext = new System.Windows.Forms.Button();
            this.buttonPrevious = new System.Windows.Forms.Button();
            this.labelStationName = new System.Windows.Forms.Label();
            this.textBoxLineNumber = new System.Windows.Forms.TextBox();
            this.buttonJoin = new System.Windows.Forms.Button();
            this.groupBoxLines.SuspendLayout();
            this.groupBoxStation.SuspendLayout();
            this.groupBoxTrain.SuspendLayout();
            this.groupBoxStationLine.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBoxLines
            // 
            this.groupBoxLines.Controls.Add(this.checkBoxCircullarLine);
            this.groupBoxLines.Controls.Add(this.textBoxLine);
            this.groupBoxLines.Controls.Add(this.buttonLine);
            this.groupBoxLines.Controls.Add(this.labelNumberLine);
            this.groupBoxLines.Location = new System.Drawing.Point(12, 12);
            this.groupBoxLines.Name = "groupBoxLines";
            this.groupBoxLines.Size = new System.Drawing.Size(200, 100);
            this.groupBoxLines.TabIndex = 0;
            this.groupBoxLines.TabStop = false;
            this.groupBoxLines.Text = "Linie";
            // 
            // checkBoxCircullarLine
            // 
            this.checkBoxCircullarLine.AutoSize = true;
            this.checkBoxCircullarLine.Location = new System.Drawing.Point(6, 65);
            this.checkBoxCircullarLine.Name = "checkBoxCircullarLine";
            this.checkBoxCircullarLine.Size = new System.Drawing.Size(72, 17);
            this.checkBoxCircullarLine.TabIndex = 2;
            this.checkBoxCircullarLine.Text = "Okrężna?";
            this.checkBoxCircullarLine.UseVisualStyleBackColor = true;
            // 
            // textBoxLine
            // 
            this.textBoxLine.Location = new System.Drawing.Point(48, 39);
            this.textBoxLine.Name = "textBoxLine";
            this.textBoxLine.Size = new System.Drawing.Size(100, 20);
            this.textBoxLine.TabIndex = 2;
            // 
            // buttonLine
            // 
            this.buttonLine.Location = new System.Drawing.Point(125, 77);
            this.buttonLine.Name = "buttonLine";
            this.buttonLine.Size = new System.Drawing.Size(75, 23);
            this.buttonLine.TabIndex = 1;
            this.buttonLine.Text = "Stwórz linię";
            this.buttonLine.UseVisualStyleBackColor = true;
            this.buttonLine.Click += new System.EventHandler(this.buttonLine_Click);
            // 
            // labelNumberLine
            // 
            this.labelNumberLine.AutoSize = true;
            this.labelNumberLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelNumberLine.Location = new System.Drawing.Point(56, 16);
            this.labelNumberLine.Name = "labelNumberLine";
            this.labelNumberLine.Size = new System.Drawing.Size(81, 20);
            this.labelNumberLine.TabIndex = 0;
            this.labelNumberLine.Text = "Numer linii";
            // 
            // groupBoxStation
            // 
            this.groupBoxStation.Controls.Add(this.buttonStation);
            this.groupBoxStation.Controls.Add(this.labelName);
            this.groupBoxStation.Controls.Add(this.textBoxStation);
            this.groupBoxStation.Location = new System.Drawing.Point(12, 144);
            this.groupBoxStation.Name = "groupBoxStation";
            this.groupBoxStation.Size = new System.Drawing.Size(200, 100);
            this.groupBoxStation.TabIndex = 1;
            this.groupBoxStation.TabStop = false;
            this.groupBoxStation.Text = "Stacje";
            // 
            // buttonStation
            // 
            this.buttonStation.Location = new System.Drawing.Point(111, 77);
            this.buttonStation.Name = "buttonStation";
            this.buttonStation.Size = new System.Drawing.Size(89, 23);
            this.buttonStation.TabIndex = 3;
            this.buttonStation.Text = "Stwórz stację";
            this.buttonStation.UseVisualStyleBackColor = true;
            this.buttonStation.Click += new System.EventHandler(this.buttonStation_Click);
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelName.Location = new System.Drawing.Point(51, 16);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(97, 20);
            this.labelName.TabIndex = 2;
            this.labelName.Text = "Nazwa stacji";
            // 
            // textBoxStation
            // 
            this.textBoxStation.Location = new System.Drawing.Point(48, 39);
            this.textBoxStation.Name = "textBoxStation";
            this.textBoxStation.Size = new System.Drawing.Size(100, 20);
            this.textBoxStation.TabIndex = 0;
            // 
            // checkBoxInterchangeStation
            // 
            this.checkBoxInterchangeStation.AutoSize = true;
            this.checkBoxInterchangeStation.Location = new System.Drawing.Point(10, 209);
            this.checkBoxInterchangeStation.Name = "checkBoxInterchangeStation";
            this.checkBoxInterchangeStation.Size = new System.Drawing.Size(98, 17);
            this.checkBoxInterchangeStation.TabIndex = 4;
            this.checkBoxInterchangeStation.Text = "Przesiadkowa?";
            this.checkBoxInterchangeStation.UseVisualStyleBackColor = true;
            // 
            // groupBoxTrain
            // 
            this.groupBoxTrain.Controls.Add(this.buttonCreate);
            this.groupBoxTrain.Controls.Add(this.radioButtonTruck);
            this.groupBoxTrain.Controls.Add(this.radioButtonTrain);
            this.groupBoxTrain.Controls.Add(this.textBoxTrain);
            this.groupBoxTrain.Controls.Add(this.textBoxTruck);
            this.groupBoxTrain.Controls.Add(this.labelTrain);
            this.groupBoxTrain.Controls.Add(this.labelTruck);
            this.groupBoxTrain.Location = new System.Drawing.Point(10, 277);
            this.groupBoxTrain.Name = "groupBoxTrain";
            this.groupBoxTrain.Size = new System.Drawing.Size(202, 161);
            this.groupBoxTrain.TabIndex = 5;
            this.groupBoxTrain.TabStop = false;
            this.groupBoxTrain.Text = "Pociągi";
            // 
            // buttonCreate
            // 
            this.buttonCreate.Location = new System.Drawing.Point(127, 138);
            this.buttonCreate.Name = "buttonCreate";
            this.buttonCreate.Size = new System.Drawing.Size(75, 23);
            this.buttonCreate.TabIndex = 14;
            this.buttonCreate.Text = "Stwórz";
            this.buttonCreate.UseVisualStyleBackColor = true;
            this.buttonCreate.Click += new System.EventHandler(this.buttonCreate_Click);
            // 
            // radioButtonTruck
            // 
            this.radioButtonTruck.AutoSize = true;
            this.radioButtonTruck.Location = new System.Drawing.Point(8, 113);
            this.radioButtonTruck.Name = "radioButtonTruck";
            this.radioButtonTruck.Size = new System.Drawing.Size(83, 17);
            this.radioButtonTruck.TabIndex = 13;
            this.radioButtonTruck.Text = "Czy wagon?";
            this.radioButtonTruck.UseVisualStyleBackColor = true;
            // 
            // radioButtonTrain
            // 
            this.radioButtonTrain.AutoSize = true;
            this.radioButtonTrain.Checked = true;
            this.radioButtonTrain.Location = new System.Drawing.Point(8, 62);
            this.radioButtonTrain.Name = "radioButtonTrain";
            this.radioButtonTrain.Size = new System.Drawing.Size(64, 17);
            this.radioButtonTrain.TabIndex = 12;
            this.radioButtonTrain.TabStop = true;
            this.radioButtonTrain.Text = "Pociąg?";
            this.radioButtonTrain.UseVisualStyleBackColor = true;
            // 
            // textBoxTrain
            // 
            this.textBoxTrain.Location = new System.Drawing.Point(129, 41);
            this.textBoxTrain.Name = "textBoxTrain";
            this.textBoxTrain.Size = new System.Drawing.Size(67, 20);
            this.textBoxTrain.TabIndex = 11;
            // 
            // textBoxTruck
            // 
            this.textBoxTruck.Location = new System.Drawing.Point(130, 90);
            this.textBoxTruck.Name = "textBoxTruck";
            this.textBoxTruck.Size = new System.Drawing.Size(66, 20);
            this.textBoxTruck.TabIndex = 10;
            // 
            // labelTrain
            // 
            this.labelTrain.AutoSize = true;
            this.labelTrain.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelTrain.Location = new System.Drawing.Point(4, 39);
            this.labelTrain.Name = "labelTrain";
            this.labelTrain.Size = new System.Drawing.Size(116, 20);
            this.labelTrain.TabIndex = 6;
            this.labelTrain.Text = "Numer pociągu";
            // 
            // labelTruck
            // 
            this.labelTruck.AutoSize = true;
            this.labelTruck.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelTruck.Location = new System.Drawing.Point(4, 90);
            this.labelTruck.Name = "labelTruck";
            this.labelTruck.Size = new System.Drawing.Size(116, 20);
            this.labelTruck.TabIndex = 7;
            this.labelTruck.Text = "Numer wagonu";
            // 
            // groupBoxStationLine
            // 
            this.groupBoxStationLine.Controls.Add(this.buttonJoin);
            this.groupBoxStationLine.Controls.Add(this.textBoxLineNumber);
            this.groupBoxStationLine.Controls.Add(this.buttonNext);
            this.groupBoxStationLine.Controls.Add(this.buttonPrevious);
            this.groupBoxStationLine.Controls.Add(this.labelStationName);
            this.groupBoxStationLine.Location = new System.Drawing.Point(355, 28);
            this.groupBoxStationLine.Name = "groupBoxStationLine";
            this.groupBoxStationLine.Size = new System.Drawing.Size(200, 100);
            this.groupBoxStationLine.TabIndex = 6;
            this.groupBoxStationLine.TabStop = false;
            this.groupBoxStationLine.Text = "Stacje do linii";
            // 
            // buttonNext
            // 
            this.buttonNext.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonNext.Location = new System.Drawing.Point(119, 23);
            this.buttonNext.Name = "buttonNext";
            this.buttonNext.Size = new System.Drawing.Size(75, 23);
            this.buttonNext.TabIndex = 2;
            this.buttonNext.Text = "+1";
            this.buttonNext.UseVisualStyleBackColor = true;
            this.buttonNext.Click += new System.EventHandler(this.buttonNext_Click);
            // 
            // buttonPrevious
            // 
            this.buttonPrevious.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.buttonPrevious.Location = new System.Drawing.Point(16, 23);
            this.buttonPrevious.Name = "buttonPrevious";
            this.buttonPrevious.Size = new System.Drawing.Size(75, 23);
            this.buttonPrevious.TabIndex = 1;
            this.buttonPrevious.Text = "-1";
            this.buttonPrevious.UseVisualStyleBackColor = true;
            this.buttonPrevious.Click += new System.EventHandler(this.buttonPrevious_Click);
            // 
            // labelStationName
            // 
            this.labelStationName.AutoSize = true;
            this.labelStationName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.labelStationName.Location = new System.Drawing.Point(12, 49);
            this.labelStationName.Name = "labelStationName";
            this.labelStationName.Size = new System.Drawing.Size(18, 20);
            this.labelStationName.TabIndex = 0;
            this.labelStationName.Text = "#";
            // 
            // textBoxLineNumber
            // 
            this.textBoxLineNumber.Location = new System.Drawing.Point(94, 52);
            this.textBoxLineNumber.Name = "textBoxLineNumber";
            this.textBoxLineNumber.Size = new System.Drawing.Size(100, 20);
            this.textBoxLineNumber.TabIndex = 7;
            // 
            // buttonJoin
            // 
            this.buttonJoin.Location = new System.Drawing.Point(57, 77);
            this.buttonJoin.Name = "buttonJoin";
            this.buttonJoin.Size = new System.Drawing.Size(75, 23);
            this.buttonJoin.TabIndex = 7;
            this.buttonJoin.Text = "Dołącz";
            this.buttonJoin.UseVisualStyleBackColor = true;
            this.buttonJoin.Click += new System.EventHandler(this.buttonJoin_Click);
            // 
            // FormMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.groupBoxStationLine);
            this.Controls.Add(this.groupBoxTrain);
            this.Controls.Add(this.checkBoxInterchangeStation);
            this.Controls.Add(this.groupBoxStation);
            this.Controls.Add(this.groupBoxLines);
            this.Name = "FormMain";
            this.Text = "FormMain";
            this.groupBoxLines.ResumeLayout(false);
            this.groupBoxLines.PerformLayout();
            this.groupBoxStation.ResumeLayout(false);
            this.groupBoxStation.PerformLayout();
            this.groupBoxTrain.ResumeLayout(false);
            this.groupBoxTrain.PerformLayout();
            this.groupBoxStationLine.ResumeLayout(false);
            this.groupBoxStationLine.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBoxLines;
        private System.Windows.Forms.TextBox textBoxLine;
        private System.Windows.Forms.Button buttonLine;
        private System.Windows.Forms.Label labelNumberLine;
        private System.Windows.Forms.GroupBox groupBoxStation;
        private System.Windows.Forms.Label labelName;
        private System.Windows.Forms.TextBox textBoxStation;
        private System.Windows.Forms.Button buttonStation;
        private System.Windows.Forms.CheckBox checkBoxCircullarLine;
        private System.Windows.Forms.CheckBox checkBoxInterchangeStation;
        private System.Windows.Forms.GroupBox groupBoxTrain;
        private System.Windows.Forms.Label labelTrain;
        private System.Windows.Forms.Label labelTruck;
        private System.Windows.Forms.Button buttonCreate;
        private System.Windows.Forms.RadioButton radioButtonTruck;
        private System.Windows.Forms.RadioButton radioButtonTrain;
        private System.Windows.Forms.TextBox textBoxTrain;
        private System.Windows.Forms.TextBox textBoxTruck;
        private System.Windows.Forms.GroupBox groupBoxStationLine;
        private System.Windows.Forms.Button buttonNext;
        private System.Windows.Forms.Button buttonPrevious;
        private System.Windows.Forms.Label labelStationName;
        private System.Windows.Forms.TextBox textBoxLineNumber;
        private System.Windows.Forms.Button buttonJoin;
    }
}

