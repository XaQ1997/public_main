﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Underground
    {
        private readonly List<Line> lineList = new List<Line>();

        /// <summary>
        /// Metoda zwracająca linię metra
        /// </summary>
        /// <param name="iter"></param>
        /// <returns></returns>
        public int GetLine(int iter)
        {
            return lineList[iter].GetNumber();
        }
    }
}
