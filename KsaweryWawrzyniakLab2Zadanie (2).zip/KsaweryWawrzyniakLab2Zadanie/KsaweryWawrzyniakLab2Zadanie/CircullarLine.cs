﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class CircullarLine:Line
    {
        public CircullarLine(int nr)
        {
            number = nr;
        }
    }
}
