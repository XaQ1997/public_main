﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class InterchangeStation:Station
    {
        private readonly List<Line> lineMerge = new List<Line>();
        public InterchangeStation(string named)
        {
            name = named;
        }


        /// <summary>
        /// Metoda zwracająca linę, która ma przesiadkę na tej stacji
        /// </summary>
        /// <param name="iter"></param>
        /// <returns></returns>
        public int GetLineMerged(int iter)
        {
            return lineMerge[iter].GetNumber();
        }

        /// <summary>
        /// Pasażer czeka
        /// </summary>
        /// <param name="passager"></param>
        public override void PassagerWait(Passager passager)
        {
            numberPassagers++;
            passagerList.Add(passager);
            if(passager.GetBegin()==name||passager.GetBegin()==null)
            {
                passager.SetBegin(name);
            }
        }
    }
}
