﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace KsaweryWawrzyniakLab2Zadanie
{
    public partial class FormMain : Form
    {
        List<Train> trainList = new List<Train>();
        List<Line> lineList = new List<Line>();
        List<Station> stationList = new List<Station>();
        int stationListIndex;

        public FormMain()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Metoda tworząca nową linię
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLine_Click(object sender, EventArgs e)
        {
            int nr = Int32.Parse(textBoxLine.Text);
            if(checkBoxCircullarLine.Checked==true)
            {
                Line line = new CircullarLine(nr);
                lineList.Add(line);
            }
            else
            {
                Line line = new Line(nr);
                lineList.Add(line);
            }
        }

        /// <summary>
        /// Metoda tworząca nową stację
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonStation_Click(object sender, EventArgs e)
        {
            string name = textBoxStation.Text;
            if(checkBoxInterchangeStation.Checked==true)
            {
                Station station = new InterchangeStation(name);
                stationList.Add(station);
            }
            else
            {
                Station station = new Station(name);
                stationList.Add(station);
            }
        }

        /// <summary>
        /// Metoda tworząca nowy pociąg albo nowy wagon
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCreate_Click(object sender, EventArgs e)
        {
            if(radioButtonTrain.Checked==true)
            {
                int nr = Int32.Parse(textBoxTrain.Text);
                Train train = new Train(nr);
                trainList.Add(train);
            }
            else
            {
                int nr = Int32.Parse(textBoxTruck.Text);
                Truck truck = new Truck(nr);
                TextBox textBox=new TextBox();
                nr = Int32.Parse(textBox.Text);
                trainList[nr].AddTruck(truck);
            }
        }

        /// <summary>
        /// Metody poruszające się po liście stacji
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            Station station = stationList[Math.Abs(stationListIndex-- % stationList.Count)];
            labelStationName.Text = station.GetName();
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {
            Station station = stationList[Math.Abs(stationListIndex++ % stationList.Count)];
            labelStationName.Text = station.GetName();
        }

        private void buttonJoin_Click(object sender, EventArgs e)
        {
            int nr = Int32.Parse(textBoxLineNumber.Text);
            lineList[nr].stationList.Add(stationList[stationListIndex]);
        }
    }
}
