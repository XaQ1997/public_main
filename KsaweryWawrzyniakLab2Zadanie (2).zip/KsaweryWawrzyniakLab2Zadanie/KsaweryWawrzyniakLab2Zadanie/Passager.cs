﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KsaweryWawrzyniakLab2Zadanie
{
    class Passager
    {
        private string begin, end;

        public string GetBegin()
        {
            return begin;
        }

        public string GetEnd()
        {
            return end;
        }

        public void SetBegin(string start)
        {
            begin = start;
        }

        public void SetEnd(string finish)
        {
            end = finish;
        }
    }

}
